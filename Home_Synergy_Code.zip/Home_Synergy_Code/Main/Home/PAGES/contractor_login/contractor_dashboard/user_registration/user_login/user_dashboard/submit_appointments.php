<?php
session_start();
require_once 'database.php'; 

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect the form data
    $contractor_id = htmlspecialchars($_POST['contractor_id']); // Get contractor_id
    $contractor_name = htmlspecialchars($_POST['contractor_name']);
    $contractor_surname = htmlspecialchars($_POST['contractor_surname']);
    $contractor_profession = htmlspecialchars($_POST['contractor_profession']);
    $appointment_date = htmlspecialchars($_POST['appointment-date']);
    $appointment_time = htmlspecialchars($_POST['appointment-time']);
    $location = htmlspecialchars($_POST['location']);
    $details = htmlspecialchars($_POST['details']);
    $created_at = date('Y-m-d H:i:s'); // Current timestamp

    $user_id = $_SESSION['user_id']; // Retrieve the logged-in user's ID

    // Check for any required fields that might be empty
    if (empty($contractor_name) || empty($contractor_surname) || empty($appointment_date) || empty($appointment_time) || empty($user_id) || empty($contractor_id)) {
        echo json_encode(["status" => "error", "message" => "All fields are required."]);
        exit;
    }

    // Prepare the SQL statement
    $sql = "INSERT INTO appointments (contractor_id, contractor_name, contractor_surname, contractor_profession, appointment_date, appointment_time, location, details, created_at, user_id) 
            VALUES ('$contractor_id', '$contractor_name', '$contractor_surname', '$contractor_profession', '$appointment_date', '$appointment_time', '$location', '$details', '$created_at', '$user_id')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo json_encode(["status" => "success", "message" => "Your booking request has been successfully sent to the contractor."]);
    } else {
        $error = "Error: " . $conn->error; // Capture the error message
        echo json_encode(["status" => "error", "message" => $error]);
    }
}
?>