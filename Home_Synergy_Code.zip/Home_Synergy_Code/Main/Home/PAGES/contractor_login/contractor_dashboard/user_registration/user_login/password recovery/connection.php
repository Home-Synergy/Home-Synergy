<?php 
$con = mysqli_connect('localhost', 'root', '', 'home_synergy');
?>